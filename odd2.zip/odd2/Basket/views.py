from django.shortcuts import render

# Create your views here.

from django.contrib.auth.models import User
from django.db import models

class Basket(models.Model):
    number_of_commodity = models.FloatField(verbose_name='تعداد کالا ها')
    sum_price = models.FloatField(verbose_name='جمع قیمت')
    commodity_list = models.ArrayField(verbose_name='لیست کلا ها'')
    customer_number = models.FloatField(verbose_name='شماره مشتری')
    cashier_number = models.FloatField(verbose_name='شماره صندوق دار')


    def user_name(self):
        return self.user.first_name + " " + self.user.last_name
    user_name.short_description = 'نام'
