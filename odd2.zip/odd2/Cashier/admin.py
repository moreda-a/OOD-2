from django.contrib import admin

# Register your models here.
from Cashier.views import Cashier


def activate(modeladmin, request, queryset):
    queryset.update(active=True)
activate.short_description = 'فعال کردن صندوق دار های انتخاب شده'


def deactivate(modeladmin, request, queryset):
    queryset.update(active=False)
deactivate.short_description = 'غیر فعال کردن صندوق دار ‌‌های انتخاب شده'


def delete(modeladmin, request, queryset):
    queryset.delete()
delete.short_description = 'حذف کردن صندوق دار های انتخاب شده'


class CashierAdmin(admin.ModelAdmin):
    list_display = ['user_name', 'phone_number', 'active']
    list_filter = ['active']
    actions = [activate, deactivate, delete]

admin.site.register(Cashier, admin_class=CashierAdmin)
admin.site.disable_action('delete_selected')
