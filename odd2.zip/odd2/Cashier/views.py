from django.shortcuts import render

# Create your views here.

from Owner.views import Owner

# Create your models here.


class Cashier(Owner):
    cashier_number = models.FloatField(verbose_name='شماره صنوق')


    class Meta:
        verbose_name = 'صندوق دار'
        verbose_name_plural = 'صندوق دار ها'
