from django.contrib import admin

# Register your models here.

from Commodity.models import Commodity

class CommodityAdmin(admin.ModelAdmin):
    list_display = ('resourceName', 'unit', 'amount', 'price', 'status', 'count', 'date')
    list_filter = ['status']
    search_fields = ['resourceName', 'status']


admin.site.register(Commodity, admin_class=OrderAdmin)
