from django.apps import AppConfig


class CommodityConfig(AppConfig):
    name = 'Commodity'
