from django.shortcuts import render

# Create your views here.
from django.contrib.auth.models import User
from django.db import models

# Create your models here.


class Commodity(models.Model):
    name = models.FloatField(verbose_name='نام')
    min_number = models.FloatField(verbose_name='تعداد حداقل')
    real_number = models.FloatField(verbose_name='تعداد فعلی')
    size = models.FloatField(verbose_name='اندازه')
    seller = models.FloatField(verbose_name='شرکت فروشنده')
    income_number = models.FloatField(verbose_name='کل خرید')
    end_date = models.FloatField(verbose_name='تاریخ انقضا')
    sign_in_time = models.FloatField(verbose_name='تاریخ ثبت')

    class Meta:
        verbose_name = 'کالا'
        verbose_name_plural = 'کالا ها'

    def user_name(self):
        return self.user.first_name + " " + self.user.last_name
    user_name.short_description = 'نام'
