from django.shortcuts import render

# Create your views here.
from django.contrib.auth.models import User
from django.db import models
from human.views import human

# Create your models here.


class Customer(human):
    demand = models.FloatField(verbose_name='میزان مطالبات')
    ranking = models.FloatField(verbose_name='رنکینگ')
    shoping = models.FloatField(verbose_name='میزان خرید')
    last_transaction = models.FloatField(verbose_name='آخرین خرید')


    class Meta:
        verbose_name = 'مشتری'
        verbose_name_plural = 'مشتری ها'
