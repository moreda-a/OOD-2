from django.shortcuts import render

# Create your views here.

from django.contrib.auth.models import User
from django.db import models
from Owner.views import Owner

# Create your models here.


class Cashier(Owner):
    cashier_number_under = models.FloatField(verbose_name='شماره صندوقدار تحت کنترل')
    fixes = models.FloatField(verbose_name='تعمیرات')



    class Meta:
        verbose_name = 'مدیر'
        verbose_name_plural = 'مدیر ها'
