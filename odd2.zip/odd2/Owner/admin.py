from django.contrib import admin

# Register your models here.
from Owner.views import Owner


def activate(modeladmin, request, queryset):
    queryset.update(active=True)
activate.short_description = 'فعال کردن صاحب های انتخاب شده'


def deactivate(modeladmin, request, queryset):
    queryset.update(active=False)
deactivate.short_description = 'غیر فعال کردن صاحب ‌‌های انتخاب شده'


def delete(modeladmin, request, queryset):
    queryset.delete()
delete.short_description = 'حذف کردن صاحب های انتخاب شده'


class OwnerAdmin(admin.ModelAdmin):
    list_display = ['user_name', 'phone_number', 'active']
    list_filter = ['active']
    actions = [activate, deactivate, delete]

admin.site.register(Owner, admin_class=OwnerAdmin)
admin.site.disable_action('delete_selected')
