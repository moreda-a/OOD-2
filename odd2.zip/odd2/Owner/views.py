from django.shortcuts import render

# Create your views here.
from django.contrib.auth.models import User
from django.db import models
from human.views import human

# Create your models here.


class Owner(human):
    start_time = models.FloatField(verbose_name='تاریخ استخدام')
    history = models.StringField(verbose_name='سابقه')
    insurance = models.FloatField(verbose_name='بیمه')
    wage = models.FloatField(verbose_name='حقوق')
    access = models.FloatField(verbose_name='سطح اختیارات')


    class Meta:
        verbose_name = 'صاحب'
        verbose_name_plural = 'صاحب ها'
