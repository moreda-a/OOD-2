from django.apps import AppConfig


class ReceiptConfig(AppConfig):
    name = 'Receipt'
