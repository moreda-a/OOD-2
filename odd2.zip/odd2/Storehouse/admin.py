from django.contrib import admin

# Register your models here.
from Storehouse.views import Storehouse


def activate(modeladmin, request, queryset):
    queryset.update(active=True)
activate.short_description = 'فعال کردن انبار های انتخاب شده'


def deactivate(modeladmin, request, queryset):
    queryset.update(active=False)
deactivate.short_description = 'غیر فعال کردن انبار ‌‌های انتخاب شده'


def delete(modeladmin, request, queryset):
    queryset.delete()
delete.short_description = 'حذف کردن انبار های انتخاب شده'


class StorehouseAdmin(admin.ModelAdmin):
    list_display = ['user_name', 'phone_number', 'active']
    list_filter = ['active']
    actions = [activate, deactivate, delete]

admin.site.register(Worker, admin_class=StorehouseAdmin)
admin.site.disable_action('delete_selected')
