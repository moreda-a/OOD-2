from django.shortcuts import render

# Create your views here.
from django.contrib.auth.models import User
from django.db import models

# Create your models here.


class Storehouse(models.Model):
    number_of_commodity = models.FloatField(verbose_name='تعداد کالا ها')
    last_time_buy = models.FloatField(verbose_name='تاریخ آخرین خرید')
    real_number = models.FloatField(verbose_name='تعداد فعلی')
    size = models.FloatField(verbose_name='اندازه')
    seller = models.FloatField(verbose_name='شرکت فروشنده')
    income_number = models.FloatField(verbose_name='کل خرید')
    end_date = models.FloatField(verbose_name='تاریخ انقضا')
    demand_commodities = models.FloatField(verbose_name='محصولات مورد نیاز')

    class Meta:
        verbose_name = 'انبار'
        verbose_name_plural = 'انبار ها'

    def user_name(self):
        return self.user.first_name + " " + self.user.last_name
    user_name.short_description = 'نام'
