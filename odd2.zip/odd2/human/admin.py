from django.contrib import admin

# Register your models here.
from human.views import human


def activate(modeladmin, request, queryset):
    queryset.update(active=True)
activate.short_description = 'فعال کردن انسان های انتخاب شده'


def deactivate(modeladmin, request, queryset):
    queryset.update(active=False)
deactivate.short_description = 'غیر فعال کردن انسان ‌‌های انتخاب شده'


def delete(modeladmin, request, queryset):
    queryset.delete()
delete.short_description = 'حذف کردن انسان های انتخاب شده'


class humanAdmin(admin.ModelAdmin):
    list_display = ['user_name', 'phone_number', 'active']
    list_filter = ['active']
    actions = [activate, deactivate, delete]

admin.site.register(Worker, admin_class=humanAdmin)
admin.site.disable_action('delete_selected')
