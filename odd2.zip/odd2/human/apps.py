from django.apps import AppConfig


class HumanConfig(AppConfig):
    name = 'human'
