from django.shortcuts import render

from django.contrib.auth.models import User
from django.db import models

# Create your models here.


class human(models.Model):
    first_name = models.FloatField(verbose_name='نام')
    second_name = models.FloatField(verbose_name='نام خانوادگی')
    phone_number = models.FloatField(verbose_name='شماره تلفن')
    active = models.BooleanField(default=False, verbose_name='فعال بودن')
    sign_in_time = models.FloatField(verbose_name='تاریخ ثبت')
    user = models.ForeignKey(User, verbose_name='کاربر')

    class Meta:
        verbose_name = 'انسان'
        verbose_name_plural = 'انسان ها'

    def user_name(self):
        return self.user.first_name + " " + self.user.last_name
    user_name.short_description = 'نام'
